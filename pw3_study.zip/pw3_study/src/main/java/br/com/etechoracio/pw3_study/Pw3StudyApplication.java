package br.com.etechoracio.pw3_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw3StudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw3StudyApplication.class, args);
	}

}
